export interface Product {
  reportId?:number;
  consultatName?:string;
  consultatMobileNumber?:number;
  consultantEmail?:string;
  experience?:number;
}

